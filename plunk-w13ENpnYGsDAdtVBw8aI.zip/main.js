/* jshint node: true */
/* global window: false, Scene: false */

"use strict";

function main() {
    Scene.Initialize("renderCanvas");
}
window.onload = main;